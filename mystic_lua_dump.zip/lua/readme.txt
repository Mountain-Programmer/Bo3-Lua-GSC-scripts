dumped using HydraX by Scobalula (https://github.com/Scobalula/HydraX)
decompiled using CoDLUIDecompiler by JariKCoding (https://github.com/JariKCoding/CoDLUIDecompiler)
hosted on Gofile

Contents:
    This zip contains pretty much all of the base LUI scripts for CoD Black Ops 3. They are already decompiled but some 
    variable renaming should be done to use them as they will not work out of the box.

Posted by Mystic@9217 (Discord) 
I give my handle in case someone or some company has an issue with me posting this, so they can contact me and I can take it down and not get sued.
Please do not contact me for help or to explain the scripts to you, you can look at Scobalula's wiki along with the modme wiki and figure it out. 

Hope this is a useful resource, happy scripting!